<#
    .SYNOPSIS
    Muestra las entradas de un archivo .zip

    .DESCRIPTION
    Muesta cada entrada de un archivo .zip con toda su informacion.

    .PARAMETER zipFile
    Direccion del archivo zip.

    .EXAMPLE
    .\TP1-ejercicio6.ps1 -zipFile .\SISOP.zip
	
	.NOTES
	Sistemas Operativos
	--------------------
	Trabajo Práctico N°1
	Ejercicio 6
	Script: TP1-ejercicio6.ps1
	
	--------------------
	Integrantes:
		Avila, Leandro - 35537983
		Di Lorenzo, Maximiliano - 38166442
		Lorenz, Lautaro - 37661245
		Mercado, Maximiliano - 37250369
		Sequeira, Eliana - 39061003
	
#>


[CmdLetBinding()]
Param(
[Parameter(Mandatory=$true)][String]$zipFile
)


if(-not (Test-Path $zipFile)){
	Write-Error 'El archivo no existe.'
	return
}

$extension = [IO.Path]::GetExtension($zipFile)
if($extension -ne '.zip'){
	Write-Error 'La extension del archivo no es correcta. Solo se permiten .zip'
	return
}
	
else{
	
	Add-Type -AssemblyName 'System.IO.Compression.FileSystem'
	
	#Voy guardando en un vector de objetos los datos de cada entrada
	foreach($sourceFile in (Get-ChildItem $zipFile)	)
	{
		$zip = [IO.Compression.ZipFile]::OpenRead($sourceFile.FullName)
			
	}
		#Utilizo los metodos propios de la clase Zip y los voy guardando en variables, son vectores tambien de objeto.
		$compressedSize = $zip.Entries.CompressedLength
		$uncompressedSize = $zip.Entries.Length
		$name = $zip.Entries.FullName
	
	
	
	for($i=0; $i -lt $name.length; $i++) #For para recorerrer el vector de objetos e ir imprimiendolos en orden.
	{ 
		
		#Comparo que el peso no sea 0, en caso de ser 0 es porque es una carpeta y la lista y daria error.
		if($compressedSize[$i] -ne 0)
		{
			#Creo el objeto PSObject que me sirve para imprimir estilo tabla personalizada
			$obj = New-Object PSObject
			$obj | Add-Member NoteProperty 'Nombre archivo'($name[$i])
			$obj | Add-Member NoteProperty 'Tamaño original'([String]($uncompressedSize[$i]/1Mb) + ' MB')
			$obj | Add-Member NoteProperty 'Tamaño comprimido'([String]($compressedSize[$i]/1Mb) + ' MB')
			$obj | Add-Member NoteProperty 'Relacion'([System.Math]::Round(($compressedSize[$i]/$uncompressedSize[$i]), 3))

			write-output $obj
		}
	}
}


<# Fin de archivo#>

