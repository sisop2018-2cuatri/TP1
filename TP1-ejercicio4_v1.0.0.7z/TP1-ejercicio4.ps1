﻿<#
    .SYNOPSIS
    Adminsitrador de stock de pasajes

    .DESCRIPTION
    Realize control de stock de pasajes mediante 
    la RESERVA o la DEVOLUCIÓN de los mismos

    .PARAMETER ciudadOrigen
    Ciudad la cual será tomada como punto de partida

    .PARAMETER ciudadDestino
    Ciudad la cual será tomada como punto de llegada

    .PARAMETER euro 
    (OPCIONAL) Representa cuantos leks son un euro

    .PARAMETER Devolucion 
    Ingresarlo si se quiere hacer una devolución de pasaje

    .EXAMPLE
    .\TP1-ejercicio4.ps1 -ciudadOrigen 'kotor' -ciudadDestino 'tirana'

    .EXAMPLE
    .\TP1-ejercicio4.ps1 -ciudadOrigen 'kotor' -ciudadDestino 'tirana' -euro 140

    .EXAMPLE
    .\TP1-ejercicio4.ps1 -ciudadOrigen 'kor' -ciudadDestino 'ti'

    .EXAMPLE
    .\TP1-ejercicio4.ps1 -ciudadOrigen 'Ko' -ciudadDestino 'T' -euro 10 -Devolucion

    .EXAMPLE
    .\TP1-ejercicio4.ps1 -ciudadOrigen 'k' -ciudadDestino 's' -Devolucion
#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$TRUE, Position=1)]
    [ValidateNotNullOrEmpty()]
    [string] $ciudadOrigen,

    [Parameter(Mandatory=$TRUE, Position=2)]
    [ValidateNotNullOrEmpty()]
    [string] $ciudadDestino,

    [Parameter(Mandatory=$FALSE, Position=3)]
    [ValidateRange(0, [int]::MaxValue)] 
    [Int] 
    $euro,
        
    [Parameter(Mandatory=$FALSE)]
    [Switch]
    $Devolucion 
)

# Buscar y abrir base de datos
$path_bdd = '.\bdd.csv';
$flag_existe_bdd = Test-Path $path_bdd;

if($flag_existe_bdd) { # si la base de datos fue encontrada
        
    # check tipo de moneda ingresado
    $precio_unidad = "euros";
    if ($euro -eq 0) {
        $precio_unidad = "leks";
    }

    # headers leidos en la base de datos
    $headers = 
        'Origen', 
        'Fecha-Hora origen', 
        'Destino', 
        'Fecha-Hora destino', 
        "Precio ($precio_unidad)", 
        'Lugares libres';

    # Importar destinos cargados en base de datos
    $bdd = Import-Csv $path_bdd -Delimiter ';' -Header $headers;

    # agregamos la propiedad 'ID' (número de fila menos uno) a cada destino
    $bdd_filter = $bdd | ForEach-Object -Begin {$index = 0} -Process {
        $_ | Select-Object @{l='ID'; e={$index}}, *;
        $index += 1;
    };

    # obtener fecha-hora de ejecución en formato "MM/dd/yyyy hh:mm AM"
    # formato 'dd/MM/yyyy hh:mm tt' = [Globalization.CultureInfo]::CreateSpecificCulture('es-AR')
    $culture_en_US = New-Object system.globalization.cultureinfo('en-US');
    $execution_datetime = Get-Date -format (($culture_en_US.DateTimeFormat.ShortDatePattern) + " hh:mm tt");

    # aplicamos los filtros:
    # ciudades que comienzan con $ciudadDestino y $ciudadOrigen
    # pasajes con Fecha-Hora desde mayor a la de ejecución.
    $bdd_filter = $bdd_filter.Where{ 
        ($_.Origen -like "$ciudadOrigen*") -and 
        ($_.Destino -like "$ciudadDestino*") -and
        ([dateTime]::Parse($_.'Fecha-Hora origen', ([Globalization.CultureInfo]::CreateSpecificCulture('es-AR'))) -gt $execution_datetime)
    };

        
    if(!$Devolucion) { # si es una nueva reserva de pasaje
        # no muestro los destinos sin lugares disponibles
        $bdd_filter = $bdd_filter.Where{ $_.'Lugares libres' -gt 0 };
    } 

    if($bdd_filter.count -gt 0) { # si hay destinos para mostrar

        # agregamos el 'ID' a los headers
        $headers = @("ID") + $headers;

        # formateamos el precio según la unidad usada para la búsqueda
        if($precio_unidad -eq "euros") {
            # mostrar precio en euros (redondeando a dos las posiciones decimales)
            $headers[5] = @{
                Label="Precio ($precio_unidad)"; 
                Expression={"" + [math]::Round($_."Precio ($precio_unidad)"/$euro,2)}};
        }

        #mostramos los destinos encontrados
        $bdd_filter | Format-Table -Property $headers -Wrap -AutoSize;

        #solicitamos al usuario el ID del destino a modificar (reserva/devolución)
        $mensaje = 'Ingrese [ID] del destino para [';
        if($Devolucion) {
            $mensaje += 'CANCELAR RESERVA';
        } else {
            $mensaje += 'RESERVAR';
        }
        $mensaje += ']: ';
            
        #verificamos que el usuario ingrese un ID válido
        do {
            Write-Host -NoNewline $mensaje;
            $inputString = Read-Host;
            $ID = $inputString -as [Int];
              
            # validamos que el ID ingresado exista
            $ok = ($ID -ne $NULL) -and ($bdd_filter.where{ $_.'ID' -eq $ID }.count -gt 0);
            if ( -not $ok ) { 
                Write-Host "ERROR: debe ingresar un [ID] de destino entre los mostrados en la tabla" -ForegroundColor Red;
                Write-Host "";
            }
        } until ($ok);
        Write-Host "[ID] de destino ingresado: [$ID]";

        # generar cambio en la base de datos de salida
        $index = 0;        
        $bdd_output = foreach ($register in $bdd) {                
            if($index -eq $ID) { # buscamos la linea para modificar
                if($Devolucion) { #aplicamos (reserva/devolución) según corresponda
                    $register.'Lugares libres' = [int]$register.'Lugares libres' + 1;
                } else {
                    $register.'Lugares libres' = [int]$register.'Lugares libres' - 1;
                }

                $destino_modificado = $register;
            } 

            $register;                
            $index++;
        }
               
        $flag_existe_bdd = Test-Path $path_bdd;
        if($flag_existe_bdd) {  # si la base de datos física aún existe               
            # guardar cambios en base de datos
            $bdd_output | ConvertTo-Csv -NoTypeInformation -Delimiter ';' | select -Skip 1 | Set-Content $path_bdd -Force -Encoding BigEndianUnicode;
            
            #mensaje de estado de la operación
            $mensaje = '';
            if($Devolucion) {
                $mensaje += 'reserva [CANCELADA]';
            } else {
                $mensaje += '[RESERVADO]';
            }
            $mensaje += ' correctamente';
            Write-Host $mensaje -ForegroundColor Green;

            # mostrar resultado de la operación
            $destino_modificado | Select-Object @{l='ID'; e={$ID}},* | Format-Table -Property $headers -Wrap -AutoSize;
        } else {
            Write-Host "ERROR: al guardar archivo '$path_bdd' no encontrado" -ForegroundColor Red;
        }            
    } else { # si no hay destinos disponibles
        Write-Host "No se encontraron destinos, intente con otras ciudades";
    }
} else { # si no se encontró la base de datos        
    Write-Host "ERROR: archivo '$path_bdd' no encontrado" -ForegroundColor Red;
}