﻿<#
.Synopsis
    Programa que cuenta el porcentaje de aparicion de distintos caracteres.
.Description
    Programa que cuenta el porcentaje de aparicion de distintos caracteres de un archivo pasado por parametro, mostrandose los resultados como tabla al final.
.EXAMPLE
    bacd1234aaA\q@#!AAB
.NOTES

 Sistemas Operativos
    -------------------
 Trabajo Práctico N°1
 Ejercicio 2
 Script: .\TP1-ejercicio2.ps1
    -------------------
 Integrantes:
     Avila, Leandro - 35.537.983
     Di Lorenzo, Maximiliano - 38.166.442
     Lorenz, Lautaro - 37.661.245
     Mercado, Maximiliano - 37.250.369
     Sequeira, Eliana - 39.061.003
    
#>

[CmdletBinding()]
Param
(
 [Parameter(Position = 0, Mandatory = $true)][ValidateNotNullOrEmpty()][String] $pathsalida
)

function validateChar{
    param(
    [char] $char
    )

    if($char -match '^[A-Za-z0-9" "\t\n]'){
        return $true
    }
        return $false
}


function addOrUpdate{
    param(
    [char] $char,
    [Hashtable] $table
    )

    if(validateChar $char -eq $true){

        $key = switch($char){
        "`t" {"Tab"}
        " " {"Espacio"}
        default {$char}
        }


        if(-NOT($apariciones.ContainsKey($key))){
            $apariciones.Add($key, 0)
        }
            $apariciones[$key] = $apariciones[$key] + 1
    }
}

if (Test-Path $pathsalida)
{
  $lineas=Get-Content -path $pathsalida
  
  #Write-Output $lineas
 
  $apariciones=@{}
  $cLineas = (Get-Content $pathsalida | Measure-Object –Line).Lines
  $cCaracteres = (Get-Content $pathsalida | Measure-Object -Character).Characters + $cLineas -1
  
  if($lineas){

   foreach($letra in $lineas.ToCharArray()){
    
    addOrUpdate $letra $apariciones
    
    }
    
     
    if(-NOT($cLineas -eq 1)){
    
    $apariciones.Add("Salto de Lineas", $cLineas-1)
    
    }
    
    foreach($llave in $($apariciones.Keys)){
    
    $headers = 
        "Name",
        @{Label="Value";Expression={ [string][math]::Round(100 * $_.Value / $cCaracteres, 2) + "%"}
    }
    }
    # mostrar resultado
    $apariciones | Format-Table -Property $headers -AutoSize -HideTableHeaders

}
 else{
    
    Write-Host "ERROR: archivo '$pathsalida' se encuentra vacio" -ForegroundColor Red
   
    }
}

 else { # si el archivo no fue encontrado
    Write-Host "ERROR: archivo '$pathsalida' no encontrado" -ForegroundColor Red
} 